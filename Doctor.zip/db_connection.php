<?php 
function OpenCon(){

	$dbhost = "localhost";
	$dbuser = "u555640968_gabriel";
	$dbpass = "123456Ab";
	$db = "u555640968_redondo";
	$conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connection failed: %s\n". $conn -> error);

	return $conn;
}

function CloseCon($conn)
{
	$conn -> close();
}

?>